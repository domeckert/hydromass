# hydromass
Hydrostatic mass profile reconstruction using X-ray and/or Sunyaev-Zeldovich data
